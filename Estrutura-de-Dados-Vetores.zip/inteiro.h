#ifndef INTEIRO_H
#define INTEIRO_H

class Inteiro{
private:
  int value;
public:
  Inteiro(int v);
  ~Inteiro();
  Inteiro();
  int getValue();
};

#endif