#ifndef REAL_H
#define REAL_H

class Real{
  private:
    double value;
  public:
    Real(double v);
    ~Real();
    Real();
    double getValue();
};

#endif