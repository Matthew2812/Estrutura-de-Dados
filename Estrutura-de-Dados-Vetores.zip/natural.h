#ifndef NATURAL_H
#define NATURAL_H

class Natural{
private:
  unsigned int value;
public:
  Natural(int v);
  ~Natural();
  Natural();
  unsigned int getValue();
};

#endif